# JobSearchServerSide
Back end for my job search android application

This is the most to up date version of my PHP scripts to my Job Search android applications. these files are for connecting to the databse and uploading and reading files. i have added the SQL export of database as it currently.
