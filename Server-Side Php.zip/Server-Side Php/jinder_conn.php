<?php
	$db_name = "forwil";
	$mysql_username = "root";
	$mymql_password = "";
	$server_name = "localhost";
	$conn = mysqli_connect($server_name, $mysql_username, $mymql_password, $db_name);
?>
